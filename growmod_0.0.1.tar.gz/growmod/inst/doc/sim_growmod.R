## ---- eval=FALSE, message=FALSE, warning=FALSE---------------------------
#  library(growmod)
#  library(lme4)
#  library(plyr)
#  library(reshape2)
#  library(ggplot2)
#  library(MASS)
#  library(knitr)

## ---- eval=FALSE---------------------------------------------------------
#  load("../../../../restarting23Feb2016/sheep data formated for package.Rdata")
#  lifespans=ddply(dat, ~ID, summarize, l=max(age))$l
#  recap=mean(!is.na(dat$size))
#  nind=length(unique(dat$ID))
#  m0=growmod(~age+I(age^2), ~age, dat, REcohort=FALSE)
#  pars=extract_coefs(m0)[,'est']
#  names(pars)=extract_coefs(m0)[,'var']
#  pars['size0_mu']=m0$fit$par['theta']
#  pars['size0_sd']=exp(m0$fit$par['log_size0_sd'])

## ---- eval=FALSE---------------------------------------------------------
#  nsim=1000
#  parnames=c(extract_coefs(m0)$var, 'nobs')
#  fits=array(dim=c(nsim, 2, length(parnames)),
#             dimnames=list(nsim=1:nsim, model=c('LMM','SSM'), pars=parnames))
#  for(i in 1:nsim)
#  {
#  	set.seed(i); cat(i,'\n') #to track down error if needed
#  	sim=simobs(pars=pars, nind=1500, lifespans=lifespans, recap=recap, sigma_obs= sigma_obs)
#    dat2=ddply(organize_data(sim, sigma_obs)$Ldat$Predictors, ~ID, mutate,
#  	  prevsize=size[match(age, age+1)]
#    )
#  	mss=try(growmod(~age+I(age^2), ~age, data=sim, REcohort=FALSE))
#  	mlm=try(lmer(size ~ prevsize + age+I(age^2) + age:prevsize +(1|ID) + (1|t), dat2,
#                 control=lmerControl(check.nobs.vs.nlev='ignore',
#                                    check.nobs.vs.rankZ='ignore',
#                                    check.nobs.vs.nRE='ignore')))
#  	if(class(mlm)=='try-error')
#  	{
#  		fits[i,j,k,'LMM',]=NA
#  	}else{
#  		fits[i,j,k,'LMM',]=c(fixef(mlm)[parnames[1:5]],
#  		                    attr(VarCorr(mlm)$ID, 'stddev'),
#  		                    attr(VarCorr(mlm)$t, 'stddev'),
#  		                    NA,
#  		                    attr(VarCorr(mlm), 'sc'),
#  		                    nrow(na.omit(dat2)))
#  	}	
#  	if(class(mss)=='try-error')
#  	{
#  		fits[i,j,k,'SSM',]=NA
#  	}else{
#  		fits[i,j,k,'SSM',]=c(extract_coefs(mss)$est, length(sim$size))
#  	}
#  }
#  save(fits, m0, file='compare lmm ssm basic.Rdata')

## ---- eval=FALSE---------------------------------------------------------
#  m=melt(fits[,,,,-c(8,10)])
#  true=extract_coefs(m0)[-8,c(1,3)]
#  colnames(true)[1:2]=c('value', 'pars')
#  true$pars=c('intercept', 'age', 'age^2', 'prevsize', 'prevsize:age',
#  		'sigma[indiv]', 'sigma[year]','sigma[process]')
#  m$pars=factor(m$pars, labels=c('intercept', 'age', 'age^2', 'prevsize', 'prevsize:age',
#  		'sigma[indiv]', 'sigma[year]','sigma[process]'))
#  m$true=true$value[match(m$pars, true$pars)]
#  m$cv_obs=m$sigma_obs/true['(Intercept)', 'value']
#  m$sigma_obs=round(m$sigma_obs, 3)
#  m$cv_obs=round(m$cv_obs, 3)
#  m$error=100*(m$value- m$true)/m$true

## ---- eval=FALSE---------------------------------------------------------
#  
#  tmplabel = function(variable,value) {
#    if (variable=='cv_obs')
#      {
#        llply(value, function(x)
#                    parse(text=paste('cv[obs]',x,sep='==')))
#      } else if (variable=='pars')
#        {
#          llply(value, function(x)
#          		parse(text=c('intercept', 'age', 'age^2', 'size[t-1]', 'size[t-1]:age', 'sigma[indiv]', 'sigma[time]','sigma[obs]','sigma[process]')[x]))
#        }
#      else
#        {
#          llply(value, function(x) parse(text=paste('p[recapture]',x,sep='==')))
#        }
#  }
#  
#  
#  dum=data.frame(cv_obs=unique(m$cv_obs),
#   				value=unique(m$sigma_obs),
#  				pars=unique(subset(m, pars=='sigma[obs]')$pars)
#  				)
#  
#  p3=ggplot(subset(m, recap==1))+geom_hline(aes(yintercept =true))+
#    geom_line(data=dum, aes(y=value, x=cv_obs))+
#    geom_point(aes(y=value, x=cv_obs, colour=model), alpha=.05)+
#    theme_bw()
#  p3+facet_grid(pars~., scale='free', switch="y", labeller= tmplabel)+ylab("estimated coefficient")+xlab("c.v. observation error")+
#  	stat_smooth(aes(y=value, x=cv_obs, colour=model), method = "lm", formula = y ~ bs(x,3))
#  ggsave("compareLMM_SMM_sim_obserr.png", height=8, width=4)
#  
#  s=subset(m, sigma_obs==.001)
#  s$true[which(s$pars=='sigma[obs]')]=0.001
#  p4=ggplot(s)+geom_hline(aes(yintercept =true))+
#    geom_point(aes(y=value, x=recap, colour=model), alpha=.05)+theme_bw()
#  p4+facet_grid(pars~., scale='free', switch="y", labeller=tmplabel)+ylab("estimated coefficient")+xlab("recapture rate")+
#  	stat_smooth(aes(y=value, x=recap, colour=model), method = "lm", formula = y ~ bs(x,3))+
#  	theme(legend.position="none")
#  ggsave("compareLMM_SMM_sim_recap.png", height=8, width=3)
#  
#  system(command="montage compareLMM_SMM_sim_recap.png compareLMM_SMM_sim_obserr.png -geometry +1+2 bias.png")

