NAint=999999
###########################################
growmod=function(Ldat, Lpin, formulaX, formulaM, DLL="growmod", silent=TRUE, selecting=FALSE, REyear=TRUE, REID=TRUE, REcohort=TRUE, REageID=FALSE,...)
{
	Ldat2=Ldat
	Lpin2=Lpin
	
	#Design matricies 
	Ldat2$X=model.matrix(formulaX, data=Ldat$Predictors)
	Lpin2$beta=rep(0, ncol(Ldat2$X))
	
	Ldat2$M=model.matrix(formulaM, data=Ldat$Predictors)
	Lpin2$eta=c(.1, rep(0, ncol(Ldat2$M)-1))
	
	#Which random effects are not being used
	map=list()
	if(!REcohort)
	{
		map$log_cohort_growth_sd=as.factor(NA) 
		map$cohort_growth_dev=as.factor(rep(NA, length(Lpin$cohort_growth_dev)))
	}
	if(!REyear)
	{
		map$log_year_growth_sd=as.factor(NA) 
		map$year_growth_dev=as.factor(rep(NA, length(Lpin$year_growth_dev)))
	}
	if(!REID)
	{
		if(REageID){stop("Models with a random slope of ID, but no intercept is not implemented.")}
		map$log_indiv_growth_sd=as.factor(NA)
		map$indiv_growth_dev=as.factor(rep(NA, length(Lpin$indiv_growth_dev)))
	}
	if(!REageID)
	{
		map$scale_indiv_cor=as.factor(NA)
		map$log_indiv_age_growth_sd=as.factor(NA) 
		map$indiv_age_growth_dev=as.factor(rep(NA, length(Lpin$indiv_age_growth_dev)))
	}
	random=c("indiv_growth_dev", "indiv_age_growth_dev", "year_growth_dev","cohort_growth_dev", "w")[c(REID, REageID, REyear, REcohort, TRUE)]
	#TMB fit
	obj=MakeADFun(data=Ldat2, parameters=Lpin2, random=random, DLL=DLL, silent=silent, map=map,...)
	fit = nlminb(obj $par, obj $fn, obj $gr, control=list(eval.max=10000, iter.max=10000))
	if(selecting){return(c(AIC=TMBAIC(fit), convergence=fit$convergence))}
	#else
	sdr=sdreport(obj)
	if(!any(is.na(summary(sdr, "fixed")))){
		return(list(parList=obj$env$parList(), fit=fit, sdr=sdr, Xnames=colnames(Ldat2$X), Mnames=colnames(Ldat2$M), formulaX= formulaX, formulaM= formulaM, AIC=TMBAIC(fit)))
	}
	#else
	warning("some values of sdreport were NA")
	return(list(parList =obj$env$parList(), fit=fit, sdr=sdr, Xnames=colnames(Ldat2$X), 
			Mnames=colnames(Ldat2$M),formulaX= formulaX, formulaM= formulaM, AIC=NA))
}
###########################################
TMBAIC=function(opt){2*length(opt[["par"]])+2*opt[["objective"]]}
###########################################
extract_coefs=function(x, CV=FALSE, bw=FALSE){
#takes  results of growmod() and returns a data frame of est, sd, z.value, and names of coefficients
	n0=1+length(x$Xnames)+length(x$Mnames)
	cf=summary(x$sdr, "fixed")[(1:n0),]
	nf=rownames(cf)
	nf[nf=="beta"]=x$Xnames
	nf[nf=="eta"]=paste0("w:",x$Mnames)
	nf[nf=="w:(Intercept)"]="w"
	rownames(cf)=nf
	cr=summary(x$sdr, "report")
	take=grep("growth_sd",rownames(cr))
	take=c(take, grep("sigma_obs",rownames(cr)))
	take=c(take, grep("sigma_proc",rownames(cr)))
	if(CV) { take = c(take, grep("CV",rownames(cr)))}
	if(bw) { take = c(take, grep("bw",rownames(cr)))}
	cr2=cr[take, ]
	c2=as.data.frame(rbind(cf,cr2))
  	c2$var=rownames(c2)
  	colnames(c2)[1]="est"
	colnames(c2)[2]="se"
	c3=transform(c2, z.value=est/se)
	return(c3)
}	

###########################################
extract_pred=function(x, Ldat, Lpin){
	rr=summary(x$sdr, "random")
	nr=rownames(rr)
	w=rr[nr=="w",]
	pred=data.frame(est=w[,1], se=w[,2], obs=Lpin$w, age=Ldat$Predictors$age, indiv=Ldat$indiv_w, lamb=Ldat$Predictors$lamb, nao=Ldat$Predictors$nao, pop=Ldat$Predictors$pop)
	return(pred)
}	
###########################################
extract_indiv_dev=function(x, Ldat, Lpin){
	i=x$parList$indiv_growth_dev
	dat=Ldat$Predictors
	dat$dev=i[Ldat$Predictors$iID+1]
	return(dat)
}	
###########################################
pred_age=function(m1, newdata, i=FALSE){
#there can only be one indiv ontogeny in newdata	
	X=model.matrix(m1$formulaX, newdata)
	M=model.matrix(m1$formulaM, newdata)
	newdata$w[newdata$age==0]=m1$parList$bw_mu
	if(i) 
	{
		newdata$wlo[newdata$age==0]=m1$parList$bw_mu-2*exp(m1$parList$log_bw_sd)
		newdata$whi[newdata$age==0]=m1$parList$bw_mu+2*exp(m1$parList$log_bw_sd)
	}	
	beta= m1$parList$beta
	eta=m1$parList$eta
	for(a in 2:length(newdata$age))
	{
		newdata$w[a]=X[a,]%*%beta + M[a,]%*%eta*newdata$w[a-1]
		if(i)
		{
			if(is.null(m1$parList$log_indiv_age_growth_sd))
			{
				newdata$wlo[a]=X[a,]%*%beta-2*exp(m1$parList$log_indiv_growth_sd)+ M[a,]%*%eta*newdata$wlo[a-1]
				newdata$whi[a]=X[a,]%*%beta+2*exp(m1$parList$log_indiv_growth_sd)+ M[a,]%*%eta*newdata$whi[a-1]
			}else{
				
			}	
			
		}	
	}
	newdata			
}
###########################################
pred_w=function(m1, newdata){

	X=model.matrix(m1$formulaX, newdata)
	M=model.matrix(m1$formulaM, newdata)
	return(X%*%m1$parList$beta + M%*%m1$parList$eta*newdata$w)
}	
###########################################
pred_expw=function(m1, newdata){

	X=model.matrix(m1$formulaX, newdata)
	M=model.matrix(m1$formulaM, newdata)
	r=summary(m1$sdr, "report")
	if("indiv_age_growth_sd" %in%rownames(r))
		stop("pred_expw is only implemented for models without random slopes")
	sumsigmasq=sum(r[grep("growth_sd",rownames(r)) , "Estimate"]^2)
	return(exp(X%*%m1$parList$beta + M%*%m1$parList$eta*newdata$w + 0.5*sumsigmasq))
}	

###########################################
simgrow=function(m1, nind=150, nyear=29, maxage=12, lifespans=NULL, ysd=NULL, psd=NULL)
{
	r=summary(m1$sdr, "report")[,1]
	pars=m1$parList
	bw_mu=pars$bw_mu
	bw_sd=r['bw_sd']
	year_growth_sd=r['year_growth_sd'] #sd among year growth intercepts
	if(!is.null(ysd)){year_growth_sd=ysd}
	sigma_proc=r['sigma_proc'] #process error
	if(!is.null(psd)){sigma_proc =psd}
	year_growth_dev=rnorm(nyear, sd= year_growth_sd)#year random effects
	indiv_growth_sd=r['indiv_growth_sd']
	if(!is.na(r['indiv_age_growth_sd']))
	{
		indiv_age_growth_sd=r['indiv_age_growth_sd']
		indiv_cor=r['indiv_cor']
	}else{
		indiv_age_growth_sd=0
		indiv_cor=0
	}
		
	byr=sample(x=nyear, size=nind, replace=TRUE)#birth year for each indiv
	if(is.null(lifespans)){	dyr=pmin(byr+ maxage, nyear)
		}else{
		dyr=pmin(byr+ sample(x=lifespans, size=nind, replace=TRUE), nyear)
	}

	eta=m1$parList$eta #AR1 coefficient for weights
	beta=m1$parList$beta #intercept and age effect of growth model
	Sigma=matrix(data=c(indiv_growth_sd*indiv_growth_sd, indiv_growth_sd*indiv_age_growth_sd*indiv_cor,
			indiv_growth_sd*indiv_age_growth_sd*indiv_cor, indiv_age_growth_sd*indiv_age_growth_sd),
			nrow=2, ncol=2)
	idev=MASS::mvrnorm(n=nind, mu=c(0,0), Sigma= Sigma)

	dat=data.frame(NULL)
	count=1
	for(i in 1:nind)
	{
		b=byr[i]
		d=dyr[i]
		temp=data.frame(w=rep(NA, d-b+1), year=b:d, ID=i, age=0:(d-b))
		temp$w[1]=rnorm(1, bw_mu, bw_sd)#birth weight
		if(d>b)
		{
			for(y in b:(d-1))#process model
			{
				temp$w[y-b+2] = rnorm(1, beta[1]+idev[i,1] +
									(beta[2]+idev[i,2])*temp$age[y-b+1] +
									beta[3]*temp$age[y-b+1]^2 + 
									(eta[1] + eta[2]*temp$age[y-b+1])*temp$w[y-b+1] +
									year_growth_dev[y], 
									sigma_proc)		
				count=count+1
			}
		}
		dat=rbind(dat, temp)		
	}	
	return(list(dat=dat, byr= byr, dyr= dyr))
}	
###########################################
simobs=function(m1, nind=150, nyear=29, maxage=12, lifespans=NULL, recap=.5, sigma_obs=0.03554119)
{
	temp= simgrow(m1=m1, nind=nind, nyear=nyear, maxage= maxage, lifespans= lifespans)
	dat=temp$dat
	byr=temp$byr
	dyr=temp$dyr
	#make sure there's at least one obser per indiv.
	#obs_sel=sample(1:nrow(dat), round(nrow(dat)* recap)) 
	sdat=split(dat, dat$ID)
	sd2=lapply(sdat, function(x){
		n=nrow(x)
		obs_sel=sample(1:n, max(round(n* recap),1))
		return(x[obs_sel,])
	})
	dat2=do.call(rbind, sd2)	
	wo=rnorm(n=nrow(dat2), mean=dat2$w, sd=sigma_obs) #observed weights
	indiv_wo=dat2$ID-1 #individuals corresponding to observed weights (-1 for C++)
	year_wo=dat2$year-1 #year corresponding to observed weights (-1 for C++)
	age_wo=dat2$age
	indiv_w= dat$ID-1 #individuals corresponding to latent weights (-1 for C++)
	year_w= dat$year-1 #year corresponding to latent weights (-1 for C++)obs=data.frame(w=wo, ind=as.factor(indiv_wo), year=year_wo)

	simobsdat=data.frame(ID=indiv_wo, year=year_wo, w=wo, age=age_wo)
	sd= simobsdat[order(simobsdat $year),]
	sd2=ddply(sd, ~ID, mutate, 
		wnext=w[match(age, age-1)]
	)
	tmp2=data.frame(iID= indiv_w+1, iyr= year_w+1, value=0:(length(year_w)-1))
	tmp2$iyr=factor(tmp2$iyr, levels=1:nyear)
	lookup_wx =acast(tmp2, iID~iyr, fill=NAint, drop=FALSE)

	Ldat=list(wo= wo, #weight observed
		indiv_wo= indiv_wo, #indiv corresponding to observed mass
		year_wo= year_wo, #year corresponding to observed mass
		byr=byr-1, #(-1 for C++)
		dyr=dyr-1, #(-1 for C++)
		indiv_w= indiv_w,
		year_w= year_w,
		age_w=dat$age,
		lookup_wx= lookup_wx,
		sigma_obs=sigma_obs,
		Predictors=dat,
		sim_obs=sd2,
		NAint=NAint
	)
	Lpin=list(w= rep(mean(wo), length(dat$w)), 
		log_year_growth_sd=0,
		log_indiv_growth_sd=0,
		log_indiv_age_growth_sd=0,
		scale_indiv_cor=0,
		log_bw_sd=0,
		bw_mu=1,
		beta=rep(0, 3),
		eta =.1,
		indiv_growth_dev=rep(0, nind),
		indiv_age_growth_dev=rep(0, nind),
		year_growth_dev=rep(0, nyear),
		log_sigma_proc=0,
		log_sigma_obs=0
	)
	return(list(Ldat =Ldat, Lpin =Lpin))
}
##########################################
LRtest <- function(full,restricted){
	
    statistic <- 2*(restricted$fit$objective - full$fit$objective)
    df <- length(full$fit$par) - length(restricted$fit$par)
    p.value <- 1-pchisq(statistic,df=df)
    data.frame(statistic,df,p.value)
}

